/* globals describe, it, expect */

describe('addition ', () => {
  it('should work', () => {
    expect(1 + 1).toEqual(2);
  });
});
